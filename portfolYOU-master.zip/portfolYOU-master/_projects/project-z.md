---
name: Project Z
tools: [JavaScript]
image:
description: This project has no image, but it is still a beautiful project inside out!
external_url: https://www.google.com
---