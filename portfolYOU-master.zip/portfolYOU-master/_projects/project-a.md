---
name: Project A
tools: [C#, XML, WPF]
image: https://thenextscoop.com/wp-content/uploads/2019/01/web-design-2019.jpg
description: This project has an individual showcase page, not just a direct link to the project site or repo. Now you have more space to describe your awesome project!
---

# Project A

Projects A is an awesome project! Just remove the direct link from the project's front matter and you will have an individual page like this for your project.

![](https://techcrunch.com/wp-content/uploads/2018/05/screen-shot-2018-05-01-at-11-30-23-am.png?w=1390&crop=1)

Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.

![](https://techcrunch.com/wp-content/uploads/2018/05/screenshot-materialio.png)

<p class="text-center">
{% include button.html link="https://github.com/YoussefRaafatNasry/portfolYOU" text="Learn More" %}
</p>