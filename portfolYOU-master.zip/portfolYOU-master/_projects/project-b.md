---
name: Project B
tools: [HTML5, CSS3]
image: https://www.infotyke.com/wp-content/uploads/2018/02/web-development-service-infotyke.png
description: Have nothing to say about the project? just use a direct link to the project site or repo.
external_url: https://www.google.com
---