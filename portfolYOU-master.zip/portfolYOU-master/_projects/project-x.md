---
name: Project X
tools: [Arduino Uno, Electronics]
image: https://cmkt-image-prd.global.ssl.fastly.net/0.1.0/ps/1143356/1160/772/m1/fpnw/wm0/creativemarket_image_front-.png?1459611806&s=04d4f811ceed88ca4716fd2551e93a36
description: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
external_url: https://www.google.com
---

# My awesome Project